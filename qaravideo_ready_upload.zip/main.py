import os
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, ContextTypes, filters
import yt_dlp

BOT_TOKEN = os.environ.get("BOT_TOKEN")

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Сәлем! YouTube сілтеме жибериң, мен MP4 яки MP3 жүктеп берем.")

async def download(update: Update, context: ContextTypes.DEFAULT_TYPE):
    url = update.message.text
    await update.message.reply_text("Видео жүктеліп атыр, күте тұрыңыз...")

    try:
        format_type = "mp4" if "mp3" not in context.args else "mp3"
        ydl_opts = {
            'format': 'bestaudio/best' if format_type == "mp3" else 'bestvideo+bestaudio/best',
            'outtmpl': f'download.%(ext)s',
            'postprocessors': [{
                'key': 'FFmpegExtractAudio',
                'preferredcodec': 'mp3',
                'preferredquality': '192',
            }] if format_type == "mp3" else []
        }

        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=True)
            filename = ydl.prepare_filename(info)
            if format_type == "mp3":
                filename = filename.rsplit(".", 1)[0] + ".mp3"

        with open(filename, 'rb') as f:
            if format_type == "mp3":
                await update.message.reply_audio(f)
            else:
                await update.message.reply_video(f)
        os.remove(filename)
    except Exception as e:
        await update.message.reply_text(f"Қате шықты: {e}")

app = ApplicationBuilder().token(BOT_TOKEN).build()
app.add_handler(CommandHandler("start", start))
app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, download))

if __name__ == '__main__':
    app.run_polling()
